﻿using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Connection
{
    public partial class MainForm : Form
    {
        private SshConnection sshConnection;
        public MainForm()
        {
            InitializeComponent();
            sshConnection = new SshConnection("192.168.1.10", "rasp", "ramgroup");
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void conect_Click(object sender, EventArgs e)
        {
            try
            {
                sshConnection.Connect();
                MessageBox.Show("SSH connection established successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error connecting to SSH: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ExecuteCommand("arm");
            MessageBox.Show("Command 'arm' executed successfully.");
        }

        private void ExecuteCommand(string command)
        {
            try
            {
                using (var client = new SshClient("192.168.1.10", "rasp", "ramgroup"))
                {
                    client.Connect();

                    if (client.IsConnected)
                    {
                        // Start an interactive session
                        var shell = client.CreateShellStream("dumb", 0, 0, 0, 0, 1024);

                        var writer = new StreamWriter(shell);
                        var reader = new StreamReader(shell);

                        writer.AutoFlush = true;

                        // Send the command
                        writer.WriteLine(command);

                        // Wait for a moment to allow the command to be executed
                        System.Threading.Thread.Sleep(13000);

                        // Read the result
                        string result = reader.ReadToEnd();
                        richTextBox2.Text = result;

                        // Additional processing or updating values based on the result can be done here

                        client.Disconnect();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error executing command: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExecuteCommandremo(string command)
        {
            try
            {
                using (var client = new SshClient("192.168.1.10", "rasp", "ramgroup"))
                {
                    client.Connect();

                    if (client.IsConnected)
                    {
                        // Start an interactive session
                        var shell = client.CreateShellStream("dumb", 0, 0, 0, 0, 1024);

                        var writer = new StreamWriter(shell);
                        var reader = new StreamReader(shell);

                        writer.AutoFlush = true;
                        writer.WriteLine(command);
                        while (true)
                        {
                            System.Threading.Thread.Sleep(10000);
                            string result = reader.ReadToEnd();
                            richTextBox2.Text = result;

                            // هنا يمكنك تحديث القيم أو القيام بأي عمل إضافي على أساس النتيجة
                        }
                        // Send the command


                        // Wait for a moment to allow the command to be executed


                        // Read the result


                        // Additional processing or updating values based on the result can be done here

                        client.Disconnect();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error executing command: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        //private void ExecuteCommand(string command)
        //{
        //    try
        //    {
        //        // تنفيذ الأمر عبر SSH
        //        using (Process process = new Process())
        //        {
        //            process.StartInfo.FileName = "plink.exe"; // قم بتعيين مسار plink.exe
        //            process.StartInfo.Arguments = $"rasp@192.168.1.10 -pw ramgroup {command}";
        //            process.StartInfo.RedirectStandardOutput = true;
        //            process.StartInfo.UseShellExecute = false;
        //            process.StartInfo.CreateNoWindow = true;

        //            process.Start();

        //            string output = process.StandardOutput.ReadToEnd();
        //            process.WaitForExit();

        //            // عرض النتيجة في TextBox أو أي عنصر تحكم آخر
        //            richTextBox1.Text = output;

        //            MessageBox.Show($"Command '{command}' executed successfully.");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show($"Error executing command: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }
        //}
        private void DisplayResult(string result)
        {
            if (richTextBox1.InvokeRequired)
            {
                richTextBox1.Invoke(new Action<string>(DisplayResult), result);
            }
            else
            {
                richTextBox1.AppendText(result + Environment.NewLine);
                richTextBox1.ScrollToCaret();
            }
        }
        private void zero_Click(object sender, EventArgs e)
        {
            ExecuteCommand("zero");
        }
        private async void ExecuteCommands(List<string> commands)
        {
            try
            {
                using (var client = new SshClient("192.168.1.10", "rasp", "ramgroup"))
                {
                    client.Connect();

                    if (client.IsConnected)
                    {
                        var shell = client.CreateShellStream("dumb", 0, 0, 0, 0, 1024);
                        var writer = new StreamWriter(shell);
                        var reader = new StreamReader(shell);
                        writer.AutoFlush = true;

                        // تغيير الدليل أولاً
                        writer.WriteLine("cd ~/code/AntennaTracker/");

                        // اقرأ النتيجة
                        string changeDirectoryResult = reader.ReadToEnd();
                        richTextBox1.Text = changeDirectoryResult;

                        if (!string.IsNullOrEmpty(changeDirectoryResult))
                        {
                            MessageBox.Show(changeDirectoryResult, "Change Directory Output");
                        }

                        // Initialize radio button colors before executing commands
                        radioButton1.BackColor = SystemColors.Control;
                        radioButton3.BackColor = SystemColors.Control;

                        // ثم تنفيذ باقي الأوامر
                        foreach (var command in commands)
                        {
                            writer.WriteLine(command);
                            if (command.Trim().Equals("track", StringComparison.OrdinalIgnoreCase))
                            {
                                await Task.Delay(10000); // انتظار لمدة 10 ثواني
                                while (true)
                                {
                                    await Task.Delay(10000); // انتظار لمدة 3 ثوانٍ

                                    // اقرأ النتيجة بعد انتظار 3 ثوانٍ وقم بطباعتها
                                    string result = reader.ReadToEnd();
                                    richTextBox1.Text = result;

                                    // هنا يمكنك تحديث القيم أو القيام بأي عمل إضافي على أساس النتيجة
                                }
                            }
                       

                            // اقرأ النتيجة
                           // string result = reader.ReadToEnd();
                            //richTextBox1.Text = result;

                            // Check the executed command and update the radio button colors
                            if (command.Trim().Equals("arm", StringComparison.OrdinalIgnoreCase))
                            {
                                radioButton2.Checked = true;
                            }
                            else if (command.Trim().Equals("zero", StringComparison.OrdinalIgnoreCase))
                            {
                                radioButton1.Checked = true;
                            }
                            else if (command.Trim().Equals("track", StringComparison.OrdinalIgnoreCase))
                            {
                                radioButton3.Checked = true;
                            }
                            else if (command.Trim().Equals("python track.py", StringComparison.OrdinalIgnoreCase))
                            {
                                radioButton4.Checked = true;
                            }

                          //  MessageBox.Show($"Command '{command}' executed successfully.");
                        }
                    }

                    client.Disconnect();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error executing commands: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private async void ExecuteCommands1(List<string> commands)
        {
            try
            {
                using (var client = new SshClient("192.168.1.10", "rasp", "ramgroup"))
                {
                    client.Connect();

                    if (client.IsConnected)
                    {
                        var shell = client.CreateShellStream("dumb", 0, 0, 0, 0, 1024);
                        var writer = new StreamWriter(shell);
                        var reader = new StreamReader(shell);
                        writer.AutoFlush = true;

                        // تغيير الدليل أولاً
                        writer.WriteLine("cd ~/code/AntennaTracker/");

                        // اقرأ النتيجة
                        string changeDirectoryResult = reader.ReadToEnd();
                        richTextBox2.Text = changeDirectoryResult;


                        // Initialize radio button colors before executing commands
                        radioButton1.BackColor = SystemColors.Control;
                        radioButton3.BackColor = SystemColors.Control;

                        // ثم تنفيذ باقي الأوامر
                        foreach (var command in commands)
                        {
                          await Task.Delay(400);

                            if (command.Trim().Equals("yaw "+textBox2.Text, StringComparison.OrdinalIgnoreCase))
                            {
                                writer.WriteLine(command);
                                await Task.Delay(4000); // انتظار لمدة 10 ثواني
                                // اقرأ النتيجة بعد انتظار 3 ثوانٍ وقم بطباعتها
                                //string result = reader.ReadToEnd();
                                //richTextBox2.Text = result;
                            }
                            if (command.Trim().Equals("pitch " + textBox1.Text, StringComparison.OrdinalIgnoreCase))
                            {
                                writer.WriteLine(command);
                                await Task.Delay(4000); // انتظار لمدة 10 ثواني
                                // اقرأ النتيجة بعد انتظار 3 ثوانٍ وقم بطباعتها
                                //string result = reader.ReadToEnd();
                                //richTextBox2.Text = result;
                            }
                            else {
                                writer.WriteLine(command); 
                            }
                            // اقرأ النتيجة
                            string result = reader.ReadToEnd();
                            richTextBox2.Text = result;

                            // Check the executed command and update the radio button colors
                            if (command.Trim().Equals("arm", StringComparison.OrdinalIgnoreCase))
                            {
                                radioButton2.Checked = true;
                            }
                            else if (command.Trim().Equals("zero", StringComparison.OrdinalIgnoreCase))
                            {
                                radioButton1.Checked = true;
                            }
                            else if (command.Trim().Equals("track", StringComparison.OrdinalIgnoreCase))
                            {
                                radioButton3.Checked = true;
                            }
                            else if (command.Trim().Equals("python track.py", StringComparison.OrdinalIgnoreCase))
                            {
                                radioButton4.Checked = true;
                            }

                   //MessageBox.Show($"Command '{command}' executed successfully.");
                        }
                    }

                    client.Disconnect();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error executing commands: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }



        private async void ExecuteCommands2(List<string> commands)
        {
            try
            {
                using (var client = new SshClient("192.168.1.10", "rasp", "ramgroup"))
                {
                    client.Connect();

                    if (client.IsConnected)
                    {
                        var shell = client.CreateShellStream("dumb", 0, 0, 0, 0, 1024);
                        var writer = new StreamWriter(shell);
                        var reader = new StreamReader(shell);
                        writer.AutoFlush = true;

                        // تغيير الدليل أولاً
                        writer.WriteLine("cd ~/code/AntennaTracker/");
                        //while (true)
                        //{
                        //    await Task.Delay(10000); // انتظار لمدة 3 ثوانٍ

                        //    // اقرأ النتيجة بعد انتظار 3 ثوانٍ وقم بطباعتها
                        //    string result = reader.ReadToEnd();
                        //    richTextBox1.Text = result;

                        //    // هنا يمكنك تحديث القيم أو القيام بأي عمل إضافي على أساس النتيجة
                        //}

                        //// اقرأ النتيجة
                        //string changeDirectoryResult = reader.ReadToEnd();
                        //richTextBox1.Text = changeDirectoryResult;

                        //if (!string.IsNullOrEmpty(changeDirectoryResult))
                        //{
                        //    MessageBox.Show(changeDirectoryResult, "Change Directory Output");
                        //}

                        //// Initialize radio button colors before executing commands
                        //radioButton1.BackColor = SystemColors.Control;
                        //radioButton3.BackColor = SystemColors.Control;

                        // ثم تنفيذ باقي الأوامر
                        foreach (var command in commands)
                        {
                           
                            if (command.Trim().Equals("touch11.py", StringComparison.OrdinalIgnoreCase))
                            {
                                await Task.Delay(4000);
                                writer.WriteLine(command);
                                await Task.Delay(4000); // انتظار لمدة 10 ثواني // انتظار لمدة 10 ثواني
                                while (true)
                                {
                                    await Task.Delay(4000); // انتظار لمدة 10 ثواني // انتظار لمدة 3 ثوانٍ

                                    // اقرأ النتيجة بعد انتظار 3 ثوانٍ وقم بطباعتها
                                    string result = reader.ReadToEnd();
                                    richTextBox1.Text = result;

                                    // هنا يمكنك تحديث القيم أو القيام بأي عمل إضافي على أساس النتيجة
                                }
                            }


                            // اقرأ النتيجة
                            // string result = reader.ReadToEnd();
                            //richTextBox1.Text = result;

                            // Check the executed command and update the radio button colors
                            if (command.Trim().Equals("arm", StringComparison.OrdinalIgnoreCase))
                            {
                                radioButton2.Checked = true;
                            }
                            else if (command.Trim().Equals("zero", StringComparison.OrdinalIgnoreCase))
                            {
                                radioButton1.Checked = true;
                            }
                            else if (command.Trim().Equals("track", StringComparison.OrdinalIgnoreCase))
                            {
                                radioButton3.Checked = true;
                            }
                            else if (command.Trim().Equals("python track.py", StringComparison.OrdinalIgnoreCase))
                            {
                                radioButton4.Checked = true;
                            }

                            //  MessageBox.Show($"Command '{command}' executed successfully.");
                        }
                    }

                    client.Disconnect();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error executing commands: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }





        private async Task PrintResultPeriodically(StreamReader reader)
        {
            while (true)
            {
                await Task.Delay(10000); // انتظار لمدة 3 ثوانٍ

                // اقرأ النتيجة بعد انتظار 3 ثوانٍ وقم بطباعتها
                string result = reader.ReadToEnd();
                richTextBox1.Text = result;

                // هنا يمكنك تحديث القيم أو القيام بأي عمل إضافي على أساس النتيجة
            }
        }
        private void pitch_Click(object sender, EventArgs e)
        {
            ExecuteCommand("pitch +5");
        }

        private void track_Click(object sender, EventArgs e)
        {
            ExecuteCommand("python track.py,");
        }

        private void disconect_Click(object sender, EventArgs e)
        {
            sshConnection.Disconnect();
            MessageBox.Show("SSH connection closed.");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            List<string> commands = new List<string>
            { 
             "python track.py",
              "arm",
              "zero",

        "pitch "+textBox1.Text,
        "yaw "+textBox2.Text,
        "track"

            };
            ExecuteCommands(commands);
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {

            List<string> commands = new List<string>
            {
             "python track.py",
              "arm",
              "zero",

        "pitch "+textBox1.Text,
        "yaw "+textBox2.Text,
            "zero",


            };
            ExecuteCommands1(commands);
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            ExecuteCommand("cd ~/code/AntennaTracker && python touch11.py");

        }

        private void button4_Click(object sender, EventArgs e)
        {
            ExecuteCommandremo("cd ~/code/AntennaTracker && python ir1_track.py");
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
