﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Renci.SshNet;
using System;

public class SshConnection
{
    private string host;
    private string username;
    private string password;
    private SshClient sshClient;

    public SshConnection(string host, string username, string password)
    {
        this.host = host;
        this.username = username;
        this.password = password;
    }

    public void Connect()
    {
        sshClient = new SshClient(host, username, password);
        sshClient.Connect();
    }

    public void ExecuteCommand(string command)
    {
        if (sshClient == null || !sshClient.IsConnected)
        {
            throw new InvalidOperationException("SSH connection is not established.");
        }

        var cmd = sshClient.CreateCommand(command);
        cmd.Execute();
    }

    public void Disconnect()
    {
        sshClient?.Disconnect();
        sshClient?.Dispose();
    }
}